RegisterCommand("help"), function()
    msg("Server's Discord: discord.gg/AxPtGDWK7f")
end, false)  

function msg(text)
    TriggerEvent("chat:addMessage", "[server]", {255,0,0}, text)
end